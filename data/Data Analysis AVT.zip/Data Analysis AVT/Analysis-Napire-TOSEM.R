### PREPARATION ###
# I assume that initially the working directory is the one where THIS file is located, 
# that MUST be /napire/Publications/TOSEM (2016)/Data analysis/Antonio
# If not please set it to that folder, otherwise the script won't work properly.

# Working directory should be renovated after each time the program runs

##  PATH and DATA PREPARATION, FUNCTIONS AND LIBRARIES  ##
source( paste(old.wd,"/Functions.R", sep="") )

## General variables ## 
source(paste(old.wd,"/Variables.R", sep=""))


for(c in countries.names){ 
 
  print(paste("--- START " , c, "----"))

  # DATA IMPORT #  

  code <- countries.codes[ which( countries.names %in% c) ]
  
  # Option "Replace numeric codes with their labels (Excel and CSV exports only)" checked
  xlsfile <- paste(current.wd,"/", c ,raw.data.folder,"Export_", code,".xls",sep="") 
  
  data.all <- import.xls(xlsfile)

  # "dispcode" should contain "31" (Completed) or "32" (Completed after break)
 
  data <- data.all[ data.all$dispcode == "Beendet (31)" | data.all$dispcode == "Beendet nach Unterbrechung (32)" | 
                      data.all$dispcode == "Completed (31)"  |  data.all$dispcode == "Completed after break (32)", ]
  
  # For export problems, we created an export just for likert variables
  xlsfile.likert <- paste(current.wd,"/", c ,raw.data.folder,"Export_", code,"_Likert.xls",sep="")
  data.likert.all <- import.xls(xlsfile.likert)
  
  # I don't know why, but Likert export do not have the dispcode variable...
  # data.likert.all$dispcode <- data.all$dispcode
  
  #data.likert <- data.likert.all[ data.likert.all$dispcode == "Beendet (31)" | data.likert.all$dispcode == "Beendet nach Unterbrechung (32)" | 
  #                    data.likert.all$dispcode == "Completed (31)"  |  data.likert.all$dispcode == "Completed after break (32)", ]
  data.likert <- data.likert.all[ data.likert.all$dispcode == 31 | data.likert.all$dispcode == 32 ,] 
    
  print("-- Data Import Finished --")
  
  # - #
  
  # DATA PREPARATION #
  
  #Read codebook
  
  codebook <- read.csv2( paste(old.wd, codebooks.folder, codebook.filename, ".csv", sep=""))
  codebook$SECTION <- as.character(codebook$SECTION)
  
  codebook$QUESTION <- as.character(codebook$QUESTION)
  
  codebook <- codebook[ !(codebook$QUESTION %in% questions.to.exclude), ]
  
  ### ANALYSIS ###
  
  #for every section of the questionnaire
  for(s in levels(as.factor(codebook$SECTION))){
  
    codebook.subset <- codebook[ codebook$SECTION == s,  ]
    codebook.subset$QUESTION <- as.factor(as.character(codebook.subset$QUESTION))
    
    # for every question in that section
    for(q in levels(codebook.subset$QUESTION)){ 

        codebook.subset$SCALE <- as.factor(as.character(codebook.subset$SCALE))
        question.scale <- unique(codebook.subset[ codebook.subset$QUESTION == q, ]$SCALE)
        
        #take option answers codes and names
        questions.vars.ids <- as.character( codebook.subset[ codebook.subset$QUESTION == q, ]$OPTION_ID)
        questions.vars.names <- as.character(codebook.subset[ codebook.subset$QUESTION == q, ]$VARNAME)
        
        #take expectations
        questions.expectations <- as.character(codebook.subset[ codebook.subset$QUESTION == q, ]$EXPECTATION)
        
        #answers with multiple options, the options share the same id
        if(question.scale == scale.multiple){ 
            questions.vars.ids <- unique(questions.vars.ids)
        }
   
        #subset data
        data.subset <- data[ , questions.vars.ids ]
        data.subset <- codify.na.multiple(data.subset) 
        
        if(question.scale == scale.binary){
          
            #Trasform Quoted/Not quoted in 0/1. 
           data.subset <- codify.quotes(data.subset) 
           colnames(data.subset) <- questions.vars.names
           
        }else if(question.scale == scale.multiple){
          
            if(ncol(data.subset) == 2){   
                colnames(data.subset) <- c(q,option.other) 
            }else {colnames(data.subset) <- q }
          
        }
          
        #build filename for results files
        q.filename <- gsub(" ", "-", q)
        q.filename <- gsub(",","",q.filename)
        filename <- paste(old.wd, results.folder, code, "/", s,"/", q.filename, sep="")
        
        #check the "other" options and treat them differently (write results in a file a part)
        option.other.ids <-  which(colnames(data.subset) == option.other)
        
        if(length(option.other.ids) > 0 ){
        
            # I save the "other" options somewhere else
            option.other.data.subset <- data.subset[, option.other.ids] 
            
            if(question.scale == scale.binary) { 
              
              colnames(option.other.data.subset) <- c("OtherSelected", "Value") 
        
            }  else if(question.scale == scale.multiple) {
              
              option.other.data.subset <- as.data.frame(option.other.data.subset) 
            }
            
            filename.others <- paste(filename,"-others",sep="")
              
              if(nchar(filename.others) > 255){
                
                filename.others <-  substr( filename.others, 1,150)
                filename.others <- paste(filename.others,"-others",sep="")
              }
            filename.others <- paste(filename.others,".csv",sep="")
            
            write.csv2(option.other.data.subset, filename.others )
            
            #I remove them from the current data structures 
            data.subset <- data.subset[ , -c(option.other.ids)] 
            data.subset <- as.data.frame(data.subset)
            questions.expectations <- questions.expectations[-which(questions.vars.names == option.other)] 
            questions.vars.ids <- questions.vars.ids[-c(option.other.ids)]
            questions.vars.names <-  questions.vars.names[-which(questions.vars.names == option.other)]
        }
        
        print(paste("-- Data preparation finished for ",s," - " , q, " -- ", sep=""))
        
        # - #
        
        # DATA ANALYSIS #
        
        
        if(question.scale == scale.binary){
          
            # make all columns numeric 
            data.subset <- apply(data.subset, MARGIN = 2, "as.numeric")
            data.subset <- as.data.frame(data.subset)
         
            # Compute bootstrap
            res <- bootstrap.compute.binary.likert(data.subset)
            
            res <- cbind(apply(data.subset, MARGIN=2, FUN="sum.na.exclude"), apply(data.subset, MARGIN=2, FUN="count.na.exclude"), res)
            colnames(res)[ 1 : 2 ] <- c("NrQuoted","NRespondents")
            
            row.names(res) <- questions.vars.names
            
            
        }else if(question.scale == scale.multiple){ #I only have a vector of frequencies in this case

            res <- bootstrap.compute.multiple(data.subset)
   
         
        }else if(question.scale == scale.likert){
         
            data.subset <- data.likert[ , questions.vars.ids]

            data.subset <- codify.na(data.subset)
            data.subset[data.subset==0] <-"" # there are some zero, but it is not in the scale
            data.subset <- apply(data.subset, MARGIN = 2, "as.numeric")
            data.subset <- as.data.frame(data.subset)

            res <- bootstrap.compute.binary.likert(data.subset)
            
             res$NRespondents <- rep(x = nrow(data.subset), times= nrow(res))      
              
            row.names(res) <-  codebook.subset[ which(codebook.subset$OPTION_ID %in% colnames(data.subset)),  ]$VARNAME 
            
          
        }

        #Achtung ! Excel doesn't held file PATHs longer than 255 charachters.
        if(nchar(filename) > 250){ # to be conservative, I take 5 letters for the extension
          filename <- substr(filename, 1,150) # to be conservative, given the long paths
        }
        
        write.csv2(res, paste(filename,".csv",sep=""))
        print(paste("Data analysis finished for ",s," - ", q, sep=""))
        
        ##
   
      }
  
    }
  
  print(paste("--- END " , c, "---- "))
  
  
}
setwd(old.wd)
