# Use this file ot subset data from one unique file and prepare files for analysis by geographical macro areas


# I assume that initially the working directory is the one where THIS file is located, 
# that MUST be /napire/Publications/TOSEM (2016)/Data analysis/Antonio
# If not please set it to that folder, otherwise the script won't work properly.

# Working directory should be renovated after each time the program runs


library(XLConnect)
library(readxl)

countries.names <- c("Austria", "Brazil", "Canada", "Estonia", "Finland", "Germany", "Ireland", "Norway" , "Sweden", "USA")  
countries.codes <- c("AT", "BR", "CA", "EE", "FI", "DE", "IE", "NO", "SE", "US")  

path.to.data.sources <- c("../../../../Surveys/2014/")  #I move the working directory to /napire/Surveys/2014/
raw.data.folder <- "/Rawdata Exports/"

#IMPORT ALL DATA
data.filename <- paste(path.to.data.sources, "AllData.xls",sep="") 
data.likert.filename <- paste(path.to.data.sources, "AllData_Likert.xls",sep="") 

data.all <- read_excel(data.filename,sheet = 1)
data.all.likert <- read_excel(data.likert.filename,sheet = 1) 

#TOFIX minor: it oculd be done more elegantly with lists, but I don't have enough time

# CE: Central Europe --> { Germany, Austria }
countries.europe.central <- c("Germany", "Austria")
data.subset <- data.all[ which(data.all$Country %in% countries.europe.central), ]
data.subset.likert <- data.all.likert[ which(data.all.likert$Country %in% countries.europe.central), ]

folder.path <- paste(path.to.data.sources, paste("Central Europe" , raw.data.folder,sep=""),sep="")
dir.create( folder.path, recursive = TRUE)
writeWorksheetToFile(file = paste(folder.path,"Export_CE.xls",sep=""), data = data.subset, sheet =  "Export 1.1" )  
writeWorksheetToFile(file = paste(folder.path,"Export_CE_Likert.xls",sep=""), data = data.subset.likert, sheet =  "Export 1.1" )  

# NEE:  North-East Europe --> {  Norway, Sweden, Finland, Ireland, Estonia }
countries.europe.north.east <- c("Norway", "Sweden", "Finland", "Ireland", "Estonia")
data.subset <- data.all[ which(data.all$Country %in% countries.europe.north.east), ]
data.subset.likert <- data.all.likert[ which(data.all.likert$Country %in% countries.europe.north.east), ]

folder.path <- paste(path.to.data.sources, paste("North-East Europe" , raw.data.folder,sep=""),sep="")
dir.create( folder.path, recursive = TRUE)
writeWorksheetToFile(file = paste(folder.path,"Export_NEE.xls",sep=""), data = data.subset, sheet =  "Export 1.1" )  
writeWorksheetToFile(file = paste(folder.path,"Export_NEE_Likert.xls",sep=""), data = data.subset.likert, sheet =  "Export 1.1" )  

# SA: South America --> { Brazil }
countries.america.south <- c("Brazil")
data.subset <- data.all[ which(data.all$Country %in% countries.america.south ), ]
data.subset.likert <- data.all.likert[ which(data.all.likert$Country %in% countries.america.south ), ]

folder.path <- paste(path.to.data.sources, paste("South America" , raw.data.folder,sep=""),sep="")
dir.create( folder.path, recursive = TRUE)
writeWorksheetToFile(file = paste(folder.path,"Export_SA.xls",sep=""), data = data.subset, sheet =  "Export 1.1" )  
writeWorksheetToFile(file = paste(folder.path,"Export_SA_Likert.xls",sep=""), data = data.subset.likert, sheet =  "Export 1.1" )  

# NA: North America --> { Us and Canada }
countries.america.north <- c("Canada", "USA")
data.subset <- data.all[ which(data.all$Country %in% countries.america.north ), ]
data.subset.likert <- data.all.likert[ which(data.all.likert$Country %in% countries.america.north ), ]

folder.path <- paste(path.to.data.sources, paste("North America" , raw.data.folder,sep=""),sep="")
dir.create( folder.path, recursive = TRUE)
writeWorksheetToFile(file = paste(folder.path,"Export_NA.xls",sep=""), data = data.subset, sheet =  "Export 1.1" )  
writeWorksheetToFile(file = paste(folder.path,"Export_NA_Likert.xls",sep=""), data = data.subset.likert, sheet =  "Export 1.1" )  

# SE: South Europe --> { Spain }









