# Use this file to aggregate results fromm all countries into a unique dataframe

# I assume that initially the working directory is the one where THIS file is located, 
# that MUST be /napire/Publications/TOSEM (2016)/Data analysis/Antonio
# If not please set it to that folder, otherwise the script won't work properly.

# Working directory should be renovated after each time the program runs


library(XLConnect)
library(readxl)

## 1- Read all countries data and aggregate them in a unique excel ##

countries.names <- c("Austria", "Brazil", "Canada", "Estonia", "Finland", "Germany", "Ireland", "Norway" , "Sweden", "USA")  
countries.codes <- c("AT", "BR", "CA", "EE", "FI", "DE", "IE", "NO", "SE", "US")   

path.to.data.sources <- c("../../../../Surveys/2014/")  #I move the working directory to /napire/Surveys/2014/

raw.data.folder <- "/Rawdata Exports/"

col.index.from.to.remove <- 188

first = 0

for(c in countries.names){ 
  
  # DATA IMPORT #  
  
  code <- countries.codes[ which( countries.names %in% c) ]
  
  xlsfile <- paste(path.to.data.sources, c ,raw.data.folder,"Export_", code,".xls",sep="") 
  xlsfile.likert <- paste(path.to.data.sources, c ,raw.data.folder,"Export_", code,"_Likert.xls",sep="") 
  

  data.country.all <- read_excel(xlsfile,sheet = 1)
  data.country.all.likert <- read_excel(xlsfile.likert,sheet = 1)     
  
  # "dispcode" should contain "31" (Completed) or "32" (Completed after break)
  
  data.country <- data.country.all[ data.country.all$dispcode == "Beendet (31)" | data.country.all$dispcode == "Beendet nach Unterbrechung (32)" | 
                      data.country.all$dispcode == "Completed (31)"  |  data.country.all$dispcode == "Completed after break (32)", ]
 
  data.country.likert <- data.country.all.likert[ data.country.all.likert$dispcode == 31 | data.country.all.likert$dispcode == 32 , ]
  
  
  
  #subject.id contains the country code
  new.ids <- paste(code,"-", data.country$lfdn,sep="") 
  data.country <- cbind( new.ids, data.country )
  data.country.likert <- cbind( new.ids, data.country.likert)    
  
  #add a acolumn with the country name
  country.vector <- rep(c, nrow(data.country) )
  data.country <- cbind( country.vector, data.country)
  data.country.likert<- cbind( country.vector, data.country.likert ) 
  
  colnames(data.country)[1:2] <- c("Country", "SubjectUniqueID")
  colnames(data.country.likert)[1:2] <-  colnames(data.country)[1:2]
    
    
  data.country <- data.country[ , -(col.index.from.to.remove:ncol(data.country))]
  data.country.likert <- data.country.likert[ , -(col.index.from.to.remove:ncol(data.country.likert))]
  

  if(first == 0){
    
    new.df <- data.country
    new.df.likert <- data.country.likert
    
    colnames(new.df)[1:2] <- c("Country", "SubjectUniqueID")
    colnames(new.df.likert)[1:2] <-  colnames(new.df)[1:2]
    
  }else{
        
    new.df <- rbind( new.df, data.country )
  
    new.df.likert <- rbind( new.df.likert, data.country.likert )
    
  }
  
  
  first <- first + 1
  
}  

writeWorksheetToFile(file = paste(path.to.data.sources,"All/Rawdata Exports/Export_ALL.xls",sep=""), data = new.df, sheet =  "Export 1.1" )  
writeWorksheetToFile(file = paste(path.to.data.sources,"All/Rawdata Exports/Export_ALL_Likert.xls",sep=""), data = new.df.likert, sheet =  "Export 1.1" )  




