### FUNCTIONS ###

# I assume that initially the working directory is the one where THIS file is located, 
# that MUST be /napire/Publications/TOSEM (2016)/Data analysis/Antonio
# If not please set it to that folder, otherwise the script won't work properly.

# Working directory should be renovated after each time the program runs

#begin test 
df <- data.likert.core[,-1]
countries <- as.character(data.likert.core[,1])

values <- data.likert.core[,2]

#end test

#INPUT:  first column country (factor), a column containing numerical values
#OUTPUT: pvalue of kruskall-wallis test
apply.ks.test <- function( countries, values ){
    
   df.temp <- cbind(countries, values)
   
   ks.res <- kruskal.test(as.numeric(values) ~ as.factor(countries) )
   
   return(ks.res$p.value)
    
}

#INPUT:  first column country (factor), a column containing numerical values
#OUTPUT: result of anova test (Pr(>F))
apply.anova.test <- function( countries, values ){
  
  df.temp <- cbind(countries, values)
  
  aov.res <- summary( aov(as.numeric(values) ~ as.factor(countries)) )

  return(aov.res[[1]][[5]][1])
  
}



### DATA PREPARATION ###


## Working directories ##

# I assume that initially the working directory is the one where THIS file is located, 
# that MUST be /napire/Publications/IST (2015)/Data analysis/Antonio
# If not please set it to that folder, otherwise the script won't work properly.

# Everytime the code is partially executed (e.g., because of an error), 
# one should reset the working directory (to do so, it should bew sufficient to execute last line "setwd(old.wd)", otherwise do it manually)

# If you add new countries, you should first recreate the results folder structure in ./results, 
# by copying and renaming the "Folder-structure-template" folder

# Clear always your environment before executing the whole script

# We need two exports: one with option "Replace numeric codes with their labels (Excel and CSV exports only)" checked, one without (for Likert scale variables). 


old.wd <- getwd()
old.wd

path.to.data.sources <- c("../../../../Surveys/2014/")  #I move the working directory to /napire/Surveys/2014/
setwd(path.to.data.sources)

current.wd <- getwd()
current.wd

codebook.filename <- "operational-codebook"


## FUNCTIONS AND LIBRARIES  ##
source( paste(old.wd,"/Functions.R", sep="") )

missing.values <- c(-77, -66, -99)

questions.to.exclude <- paste(
  "Considering your personally experienced problems-stated in the previous question-, which ones would you classify as the five most critical ones -ordered by their relevance-Problem ",
  seq(1:5), sep="")

#folders
raw.data.folder <- "/Rawdata Exports/"
results.folder <- "/results/"
codebooks.folder <- "/operational-codebooks/"


## DATA IMPORT ##

c <- "All" 
code <- "ALL"

xlsfile <- paste(current.wd,"/", c ,raw.data.folder,"Export_", code,".xls",sep="") 

data.all <- import.xls(xlsfile)

# "dispcode" should contain "31" (Completed) or "32" (Completed after break)

data <- data.all[ data.all$dispcode == "Beendet (31)" | data.all$dispcode == "Beendet nach Unterbrechung (32)" | 
                    data.all$dispcode == "Completed (31)"  |  data.all$dispcode == "Completed after break (32)", ]

# For export problems, we created an export just for likert variables
xlsfile.likert <- paste(current.wd,"/", c ,raw.data.folder,"Export_", code,"_Likert.xls",sep="")
data.likert.all <- import.xls(xlsfile.likert)



# I don't know why, but Likert export do not have the dispcode variable...
# data.likert.all$dispcode <- data.all$dispcode

#data.likert <- data.likert.all[ data.likert.all$dispcode == "Beendet (31)" | data.likert.all$dispcode == "Beendet nach Unterbrechung (32)" | 
#                    data.likert.all$dispcode == "Completed (31)"  |  data.likert.all$dispcode == "Completed after break (32)", ]
data.likert <- data.likert.all[ data.likert.all$dispcode == 31 | data.likert.all$dispcode == 32 ,] 

print("-- Data Import Finished --")


## KRUSKAL WALLIS TEST vs ANOVA ## 


# KRUSKAL WALLIS TEST see http://www.r-tutor.com/elementary-statistics/non-parametric-methods/kruskal-wallis-test
# ANOVA see http://www.r-tutor.com/category/statistical-concept/anova

data.likert$Country <- as.factor(data.likert$Country)

# example 

# Binary
# How do you elicit requirements - interviews #1 yes ; 0 no

kruskal.test(data.likert$v_437 ~ data.likert$Country, data = data.likert)
summary(aov(data.likert$v_437 ~ data.likert$Country, data = data.likert))

# Multiple scale
# How do you document non-functional requirements 
#- 1  We use quantified textual requirements
# 2	We use non-quantified textual requirments
# 3	Other

kruskal.test(data.likert$v_451 ~ data.likert$Country, data = data.likert) 
summary(aov(data.likert$v_451 ~ data.likert$Country, data = data.likert))

# Likert scale 
# Which reasons do you agree with as a motivation to define a company 
# standard for requirements engineering in your company  
# likert	v_421		Compliance to regulations and standards (like CMMI)

kruskal.test(data.likert$v_421 ~ data.likert$Country, data = data.likert) 
summary(aov(data.likert$v_421 ~ data.likert$Country, data = data.likert))

# Template to extract data

ks.res <- kruskal.test(data.likert$v_437 ~ data.likert$Country, data = data.likert)
ks.res$p.value

aov.res <- summary(aov(data.likert$v_437 ~ data.likert$Country, data = data.likert))
aov.res[[1]][[5]][1]

## COMPUTATION ##

# codebook #
codebook <- read.csv2( paste(old.wd, codebooks.folder, codebook.filename, ".csv", sep=""))
codebook$SECTION <- as.character(codebook$SECTION)
codebook$QUESTION <- as.character(codebook$QUESTION)
codebook <- codebook[ !(codebook$QUESTION %in% questions.to.exclude), ]

data.likert.core <- cbind(data.likert$Country, data.likert[ ,(10: length(data.likert) )] )


# remove char columns 

var.char <- codebook[ codebook$VALUE.multiple.notes == "varchar", ]$OPTION_ID 

length(var.char)
ncol(data.likert.core)
data.likert.core <- data.likert.core[ ,-which(names(data.likert.core) %in% var.char)]
ncol(data.likert.core)

var.others <- codebook[ codebook$VARNAME == "Other", ]$OPTION_ID 
length(var.others)
data.likert.core <- data.likert.core[ ,-which(names(data.likert.core) %in% var.others)]
ncol(data.likert.core)

var.demographics <- c("v_216", "v_540", "v_23", "v_15", "v_11", "v_401")
data.likert.core <- data.likert.core[ ,-which(names(data.likert.core) %in% var.demographics)]
ncol(data.likert.core)

var.text <- c("v_391","v_392","v_393","v_394","v_395",
              "v_508","v_509","v_510","v_511","v_512",
              "v_513","v_514","v_515","v_516","v_517",
              "v_266","v_267")
data.likert.core <- data.likert.core[ ,-which(names(data.likert.core) %in% var.text)]

# Manual addition (no time for checking proper cause)
# For some reason, v_451 and v_453 are lefto ouf of data.likert.core: I do it manually

data.likert.core$v_451 <- data.likert$v_451
data.likert.core$v_453 <- data.likert$v_453

data.likert.core <- codify.na(data.likert.core)
colnames(data.likert.core)[1] <-"Country"

# write.csv(data.likert.core,  paste(old.wd,"/temp.data.likert-core.csv",sep=""))


ks.result <- apply(X = data.likert.core[,-1],MARGIN = 2, FUN=apply.ks.test, countries =  data.likert.core[,1] )
ks.result <- as.data.frame(ks.result)
colnames(ks.result) <- c("KS-pval")
  
write.csv2(ks.result, paste(old.wd,results.folder, "ALL/country-effect-ks.csv", sep = ""))

anova.res <- apply(X = data.likert.core[,-1],MARGIN = 2, FUN=apply.anova.test, countries =  data.likert.core[,1] )
anova.res <- as.data.frame(anova.res)
colnames(anova.res) <- c("AOV-PrF")

write.csv2(anova.res, paste(old.wd,results.folder, "ALL/country-effect-aov.csv", sep = ""))


# drafts for effect size

library(effsize)
cohen.d(as.numeric(values),as.factor(countries))

res <- summary( aov(as.numeric(values) ~ as.factor(countries)) )
rsquared <- res[[1]][2][[1]][1]

cohen.f2 <- (rsquared / (1 -rsquared))
