scale.likert <- "likert"
scale.binary <- "binary"
scale.multiple <- "multiple" 

option.other <- "Other"

alternative.greater <- "greater"
alternative.lower <- "less" 

not.quoted <- "not quoted"
quoted <- "quoted"

status.quo <- "status-quo"
codebook.filename <- "operational-codebook"

missing.values <- c(-77, -66, -99)

questions.to.exclude <- paste(
  "Considering your personally experienced problems-stated in the previous question-, which ones would you classify as the five most critical ones -ordered by their relevance-Problem ",
  seq(1:5), sep="")


countries.names <- c("Austria", "Brazil", "Canada", "Estonia", "Finland", "Germany", "Ireland", "Norway" , "Sweden", "USA") 
countries.codes <- c("AT","BR","CA", "EE","FI", "DE", "IE", "NO", "SE", "US")  

# For ALL data . Uncomment when you need analysis only for all ,
# or substitute All/ALL with a specific country name/code
countries.names <- c("All") 
countries.codes <- c("ALL")  

# Areas

countries.areas.names <- c("Central Europe", "North-East Europe", "North America", "South America") # I avoid South America because is as Brazil
countries.areas.codes <- c("CE", "NEE", "NA", "SA")

#countries.names <- c(countries.names,countries.areas.names)
#countries.codes <- c(countries.codes,countries.areas.codes)

#folders
raw.data.folder <- "/Rawdata Exports/"
results.folder <- "/results/"
codebooks.folder <- "/operational-codebooks/"

