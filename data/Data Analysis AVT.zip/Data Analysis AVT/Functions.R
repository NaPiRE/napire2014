## Working directories ##

# I assume that initially the working directory is the one where THIS file is located, 
# that MUST be /napire/Publications/TOSEM (2016)/Data analysis/Antonio
# If not please set it to that folder, otherwise the script won't work properly.

# Everytime the code is partially executed (e.g., because of an error), 
# one should reset the working directory (to do so, it should bew sufficient to execute last line "setwd(old.wd)", otherwise do it manually)

# If you add new countries, you should first recreate the results folder structure in ./results, 
# by copying and renaming the "Folder-structure-template" folder

# Clear always your environment before executing the whole script

# We need two exports: one with option "Replace numeric codes with their labels (Excel and CSV exports only)" checked, one without (for Likert scale variables). 


old.wd <- getwd()
old.wd

path.to.data.sources <- c("../../../../Surveys/2014/")  #I move the working directory to /napire/Surveys/2014/
setwd(path.to.data.sources)

current.wd <- getwd()
current.wd


## Libraries ##  TOFIX minor: automatic loading of packages

list.of.packages <- c("XLConnect","readxl", "Hmisc", "boot", "foreach")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)){
  
  install.packages(new.packages)
  library(new.packages)
  
} 

library("XLConnect")
library("readxl")
library("Hmisc")
library("boot")
library("foreach")

## -- -- #

## FUNCTIONS ## 


#INPUT: a dataframe of data with binay answers to apply bootstrap
#OUTPUT: a dataframe of result
bootstrap.compute.binary.likert <- function(data.subset){
  
    res <- data.frame(rbind(rep(0,3)))

    b <- apply(na.exclude(data.subset), MARGIN = 2, FUN = "bootstrap.samplemean")
    
    foreach(i = b) %do% {
      
      ci <- boot.ci(i, type = "norm")  
      row <- c(i$t0, ci$normal[2], ci$normal[3] )
      res <- rbind( res, row )   
    }
    
    names(res) <- c("Estimate", "95Conf.int.low", "95Conf.int.up")
    res <- res[-1,]
    
    return(res)
}


# Input: a dataset with multiple options anwers to apply bootstrap
# Output: bootstrap object
bootstrap.compute.multiple <- function(data.subset){
  
  freq <- data.frame( table( data.subset) )
  names(data.subset) <- c("Answer")
  names(freq) <- c("Option", "Freq")
  
  res <- data.frame(rbind(rep(0,3)))
  
  blist <- list()    
  
  foreach(f = freq$Option) %do% {
    answers <- as.character(na.exclude(data.subset$Answer)) 
    answers[ grep(pattern = f, x=answers,  fixed = TRUE) ]  <- "marker"
    blist[[as.character(f)]] <- boot(answers, myprop, R=1000) 
  }
  
  foreach(i = blist) %do% {
    ci <- boot.ci(i, type = "norm")  
    row <- c(i$t0, ci$normal[2], ci$normal[3] )
    res <- rbind( res, row )   
  }
  
  names(res) <- c("Estimate", "95Conf.int.low", "95Conf.int.up")
  res <- res[-1,]
  
  row.names(res) <- freq$Option
  
  res <- cbind(freq$Freq,  rep( nrow(na.exclude(data.subset)) , nrow(freq) ) , res)
  colnames(res)[ 1 : 2 ] <- c("NrQuoted","NRespondents")
  
  return(res)
  
}

# Input: a vector of numeric data
# Output: bootstrap object
bootstrap.samplemean <- function(x){
  
  b <- boot(x, samplemean, R=1000)
  
  return(b)
  
}


#INPUT: row names of a question sub datasets, a dataframe from codebook with two columns: option name and expectation
#OUTPUT: a vector containing the expectations in the right order
assign.expectations <- function( vector.row.names , df.questions.and.expectations ){
  
  if( nrow(df.questions.and.expectations) > length(vector.row.names) ){
    
    cat("\n-----\n", file=stderr())
    cat( paste("Watch out, I could not find the following expectations: ", sep="\n"), file=stderr() )
    cat(  paste(as.character( df.questions.and.expectations[  ! (df.questions.and.expectations$VARNAME %in% vector.row.names) , ]$VARNAME )) )
    cat("\n-----\n", file=stderr())
    
    df.questions.and.expectations <- df.questions.and.expectations[ df.questions.and.expectations$VARNAME %in% vector.row.names , ]
    
  }else if(length(vector.row.names) > nrow(df.questions.and.expectations)){
    
    cat("\n-----\n", file=stderr())
    cat( paste("Watch out, I could not find the following expectations: ", sep="\n"), file=stderr() )
    cat(  paste(as.character( vector.row.names[ !(vector.row.names %in% df.questions.and.expectations$VARNAME)] ) ) )
    cat("\n-----\n", file=stderr())
    
    vector.row.names <- vector.row.names[ vector.row.names %in% df.questions.and.expectations$VARNAME ]
  }
  
  res.vector <- c()
  
  
  for(v in vector.row.names){
    
    n <- which( df.questions.and.expectations[,1] ==  v)
    res.vector <- c(res.vector,as.character(df.questions.and.expectations[n,2] ) )
  }
  
  return(res.vector)
  
}

#INPUT: a dataframe
#OUPUT: the data frame with non valid cells values transformed in empty spaces
codify.na <- function(data.subset){
  
  data.subset <- as.matrix(data.subset)
  
  data.subset[data.subset==-77 | data.subset==-66 | data.subset==-99 | data.subset==""]<-NA
  data.subset[data.subset=="-77.000000" | data.subset=="-66.000000" | data.subset=="-99.000000"]<-NA  #some exports are in the form -77.000000
  
  data.subset <- as.data.frame(data.subset)
  
  return(data.subset)
  
}

#INPUT: a vector of binary data
#OUTPUT: the lenght of the vector excluding the NAs
count.na.exclude <- function( vector.binary ){
  
  return( length(na.exclude(vector.binary) ) )
  
}

#INPUT: a dataframe of multiple option answers
#OUPUT: the data frame with non valid cells values transformed in empty spaces
codify.na.multiple <- function(data.subset){
  
  data.subset <- as.matrix(data.subset)
  
  data.subset[data.subset==-77 | data.subset==-66 | data.subset==-99 | data.subset==0 | data.subset==""]<-NA
  data.subset[data.subset=="-77.000000" | data.subset=="-66.000000" | data.subset=="-99.000000" | data.subset=="0.000000"]<-NA  #some exports are in the form -77.000000
  
  data.subset <- as.data.frame(data.subset)
  
  return(data.subset)
  
}


#INPUT: a dataframe
#OUPUT: the data frame with cells values "QUOTED" transformed in 1 and "NOT QUOTED" in 0
codify.quotes <- function(data.subset){
  
  data.subset <- as.matrix(data.subset)
  
  data.subset[data.subset==quoted]<-1
  data.subset[data.subset==not.quoted]<-0
  
  data.subset <- as.data.frame(data.subset)
  
  return(data.subset)
  
}

#INPUT: a vector of likert votes
#OUTPUT: dataframe with two colums: lower and upper bound t distribution 95% confidence interval
compute.conf.int.t <- function( vector.likert){
  
  v <- as.numeric(na.exclude(vector.likert))
  
  n = length(v)
  s = sd(v)
  a = mean(v)
  
  error <- qt(0.975,df=n-1)*s/sqrt(n)
  left <- a-error
  right <- a+error
  
  return(cbind(left,right))
}


#INPUT: path to a excel file
#OUTPUT: the data contained in the "Export 1.1." sheet
import.xls <- function(xlsfile){
  
  #Old lines for XLCOnnect, which created some problems when opening two excel files in the same script file
  #wb <- loadWorkbook(xlsfile, create = FALSE)
  #data <- readWorksheet(wb, sheet = "Export 1.1")
  
  data <- read_excel(xlsfile,sheet = 1)
  
  return(data)
}

#INPUT: estimation function for bootstrap that consumes data x and a vector of indices i.
#OUTPUT: 
myprop<-function(x,i){
  return( sum(x[i]=="marker")/length(x) )
}

#INPUT: a vector containing the lower bounds of the confident intervals
#OUTPUT: a vector of verdicts on likelihoods, according to the thresholds defined
prop.test.verdict <- function(lower.conf.int.vector) {
  
  res <- c()
  for(i in seq(1,length(lower.conf.int.vector))){
    
    v <- lower.conf.int.vector[i] 
    if(v < 0.10) { res <- c(res,"Unlikely") }
    else if( v < 0.25 ) { res <- c(res,"Probable") }
    else if( v < 0.50 ) { res <- c(res,"Likely") }
    else { res <- c(res,"Very Likely") }
  }
  
  return(res)
  
}

#Input: estimation function for bootstrap that consumes data x and a vector of indices d.
# Output: the mean
samplemean <- function(x, d) {
  
  return(mean(x[d]))
  
}

#INPUT: a vector of binary data
#OUTPUT: the sum of vector's elements excluding the NAs
sum.na.exclude <- function( vector.binary ){
  
  return(sum(na.exclude(vector.binary)))
  
}
