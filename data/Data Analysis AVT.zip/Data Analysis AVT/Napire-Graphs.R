### Napire Graphs ###

# I assume that initially the working directory is the one where THIS file is located, 
# that MUST be /napire/Publications/TOSEM (2016)/Data analysis/Antonio
# If not please set it to that folder, otherwise the script won't work properly.

# Working directory should be renovated after each time the program runs

# to invoke function strwrap to automatically break long lines
#install.packages("stringr")
library("stringr")

## DIRECTORY PREPARATION, FUNCTIONS AND LIBRARIES  ##
old.wd <- getwd()
source( paste(old.wd,"/Functions.R", sep="") )
source(paste(old.wd,"/Variables.R", sep=""))

# DEBUG : flush output
foreach( i = seq(1,100))%do%{dev.off()}

# I need to cycle over the folders in /Data Analysis/Antonio/results/ALL/sectionX and 
# not scanning the coodebook, because I had to shorten filenames due to Excel path limits
# (being filenames corresponding to questions in the codebook)

all.results.folder <- paste(old.wd, results.folder, "ALL", sep="")

foreach(r = list.dirs(all.results.folder) ) %do% {
  

  print(paste(" #### STARTING DIR " , r ,"####", sep=" "))
  
  foreach(f = list.files(r)) %do% {
    
    ### BEING DEBUG 
    # r=paste(all.results.folder,"/status-quo-in-RE-Process-standard",sep="")
    # filepath = paste(r,"/How-do-you-align-the-software-test-with-the-requirements-others.csv", sep="")
    # filepath = paste(r,"/Is-the-requirements-engineering-standard-mandatory-and-practiced.csv",sep="")
    # substring(f, nchar(f)-nchar("-others.csv")+1, nchar(f) )
    ### END DEBUG
   
    # In every section folder, exclude filenames ending with "-others.csv", and process the remaining ones
    
    if( substring(f, nchar(f)-nchar("-others.csv")+1, nchar(f) ) != "-others.csv" ) {
      
        filepath <- paste(r,"/",f,sep="")
        
        
          # HERE PLOT CODE
          # template customized from https://rpubs.com/azuoza/52698
          if(file.info(filepath)$size != NULL || file.info(filepath)$size > 0){
            
            data <- read.csv2(filepath);  
            
            # The tables inside those processable files have the following structure:
            
            # Binary answers:  "NrQuoted","NRespondents", "Estimate", "95Conf.int.low", "95Conf.int.up"
            # Multiple option answers: "NrQuoted","NRespondents", "Estimate", "95Conf.int.low", "95Conf.int.up"
            # Likert scale answers: "NRespondents", "Estimate", "95Conf.int.low", "95Conf.int.up"
            
            # For all, I  plot the Estimate and the confidence range
  
            
            # However: Binary and multiple option are percentages
            
            if(ncol(data) == 6) {
              
                print(paste(" #### STARTING GRAPH" ,filepath,"6 cols ####", sep=" "))
              
                data.plot <- ggplot(data = data, aes(x = X, y = Estimate,sep="") ) +
             
                geom_bar(stat="identity", fill="steelblue", width=.3 ) + # adding bar plot  #position = position_dodge()
              
                #coord_flip() +
                  
                geom_errorbar(aes(ymin=X95Conf.int.low, ymax=X95Conf.int.up), #adding error bars
                             width=.15,
                             position=position_dodge(.9)) +
                 
                
                  geom_text(aes(y=rep(0.01, times = nrow(data)),    # Right way to add labels on the bar plot
                                ymax=rep(0.01, times = nrow(data)),
                                label=paste(round(Estimate*100,1),"%",sep="") , 
                                angle = 0 ), #
                            size = 2,
                            position = position_dodge(width=1)) +  
                  
                 #theme(axis.text = element_text(colour = "black", size = 10), 
                  
                  theme(axis.text.x = element_text(angle = 45, hjust = 1, 
                                      colour = "black", size = 6),
                         axis.title.y = element_text(size = 6))  +
                
                  scale_x_discrete(labels = function(x) str_wrap(data$X, width = 75)) +
                 
                  theme(plot.margin = unit(c(1,1,1,3), "cm")) +
                  
                  xlab("Answers") +
                  ylab("Ratio of quoted options")
            
            }else if(ncol(data) == 5){ 
              
              #LIKERT answers are values from 1 to 5
              print(paste(" #### STARTING GRAPH" ,filepath,"5 cols ####", sep=" "))
              
              #abbreviate long titles 
             
              #data$newX <- strwrap(data$X, width = 30)
              
                
              data.plot <- 
                
                ggplot(data = data, aes(x =X, y = Estimate) ) +
                           
                geom_point(stat="identity" ) + # adding bar plot  #position = position_dodge()
                
               # coord_flip() +
                
                geom_errorbar(aes(ymin=X95Conf.int.low, ymax=X95Conf.int.up), #adding error bars
                              width=.15,
                              position=position_dodge(.9)) +
              
                ylim(1,5) +
              
                geom_text(aes(y=rep(1.25, times = nrow(data)),    # Right way to add labels on the bar plot
                            ymax=rep(1.25, times = nrow(data)),
                            label=round(Estimate,1)) , 
                        size = 3,
                        position = position_dodge(width=1)) +  
  
                theme(axis.text.x = element_text(angle = 45, hjust = 1, 
                                    colour = "black", size = 6),
                      axis.title.y = element_text(size = 6))  +
                
                scale_x_discrete(labels = function(x) str_wrap(data$X, width = 75)) +
                
                theme(plot.margin = unit(c(1,1,1,3), "cm")) +
                
                xlab("Answers") + 
                ylab("Likert scale values")
     
            } 
           
            # Graph is saved  in the same folder of the results files
            data.plot.name <- paste( substring( filepath, 0, nchar( filepath)-3 ), "pdf", sep="")
            
            if(file.exists(data.plot.name)){
              file.remove(data.plot.name)
            }
            pdf(data.plot.name)
            print(data.plot)
            dev.off()
            
            print(paste(" #### ENDED GRAPH" ,filepath,"####", sep=""))  
            

        }else { # CASE FILE NULL
          
          write(paste(" #### FILE " ,filepath," NOT PROCESSED: EMPTY FILE ####", sep=""), stderr())
       
        }
        
    } # case ends with -others.csv
    else {
      
          write(paste(" #### FILE " ,filepath," NOT PROCESSED: ENDS WITH OTHERS ####", sep=""), stderr())
      
    }
    
    
  }
  print(paste(" #### STARTING DIR " , r ,"####", sep=""))
  
}




